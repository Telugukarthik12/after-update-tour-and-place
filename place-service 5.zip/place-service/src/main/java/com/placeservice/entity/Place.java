package com.placeservice.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@RequiredArgsConstructor
public class Place {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer placeId;
	
	
	@NotBlank(message = "Place name cannot be blank") 
    @Size(min = 2, max = 50, message = "Place name must be between 2 and 50 characters")
    @Pattern(regexp = "^[a-zA-Z0-9\\s'-]+$", message = "Invalid characters in place name")
	private String placeName;
	
	
	private String images;
	
	@NotBlank(message = "Address cannot be blank")
	private String address;
	
	@NotBlank(message = "Area cannot be blank")
	private String area;
	
	@NotNull(message = "Distance cannot be null")
    @PositiveOrZero(message = "Distance must be a non-negative number")
	private Double distance;
	
	@NotBlank(message = "description cannot be blank")

	private String description;
	
	@NotBlank(message = "Tags cannot be blank")
	private String tags;

}
