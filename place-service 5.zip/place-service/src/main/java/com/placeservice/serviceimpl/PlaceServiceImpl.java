package com.placeservice.serviceimpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.placeservice.advices.PlaceNotFoundException;
import com.placeservice.dto.PlaceDTO;
import com.placeservice.entity.Place;
import com.placeservice.repository.PlaceRepository;
import com.placeservice.service.PlaceService;

import java.util.ArrayList;
import java.util.List;

@Service
public class PlaceServiceImpl implements PlaceService {

    private static final Logger logger = LoggerFactory.getLogger(PlaceServiceImpl.class);

    @Autowired
    private PlaceRepository placerepository;

    @Override
    public ResponseEntity<String> addPlace(PlaceDTO placeDto) {
        Place place = new Place();
        Place placeName = placerepository.findByPlaceName(placeDto.getPlaceName());
        if (placeName != null) {
            if (placeName.getPlaceName().equalsIgnoreCase(placeDto.getPlaceName())) {
                logger.warn("Place already exists. Choose a different place name: {}", placeDto.getPlaceName());
                return new ResponseEntity<>("Place already exists, Choose a different place name", HttpStatus.CONFLICT);
            }
        } else {
            place.setPlaceName(placeDto.getPlaceName());
            place.setImages(placeDto.getImages());
            place.setAddress(placeDto.getAddress());
            place.setArea(placeDto.getArea());
            place.setDistance(placeDto.getDistance());
            place.setDescription(placeDto.getDescription());
            place.setTags(placeDto.getTags());
            placerepository.save(place);
            logger.info("Place added successfully: {}", placeDto.getPlaceName());
        }
        return new ResponseEntity<>("Places added successfully", HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<List<PlaceDTO>> getAllPlaces() {
        List<PlaceDTO> listDtoplace = new ArrayList<>();
        List<Place> listEntity = placerepository.findAll();
        for (Place place : listEntity) {
            PlaceDTO placeDTO = new PlaceDTO();
            placeDTO.setPlaceId(place.getPlaceId());
            placeDTO.setPlaceName(place.getPlaceName());
            placeDTO.setImages(place.getImages());
            placeDTO.setAddress(place.getAddress());
            placeDTO.setArea(place.getArea());
            placeDTO.setDistance(place.getDistance());
            placeDTO.setDescription(place.getDescription());
            placeDTO.setTags(place.getTags());
            listDtoplace.add(placeDTO);
        }
        logger.info("Retrieved all places successfully");
        return new ResponseEntity<>(listDtoplace, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<String> updatePlaces(PlaceDTO placeDto) throws Throwable {
        Place place = placerepository.findById(placeDto.getPlaceId()).orElse(null);
        if (place != null) {
            place.setPlaceName(placeDto.getPlaceName());
            place.setImages(placeDto.getImages());
            place.setAddress(placeDto.getAddress());
            place.setArea(placeDto.getArea());
            place.setDistance(placeDto.getDistance());
            place.setDescription(placeDto.getDescription());
            place.setTags(placeDto.getTags());
            placerepository.save(place);
            logger.info("Details updated successfully for placeId: {}", placeDto.getPlaceId());
            return new ResponseEntity<>("Details Updated Successfully", HttpStatus.OK);
        } else {
            logger.error("Place not found for updating. PlaceId: {}", placeDto.getPlaceId());
            throw new PlaceNotFoundException(placeDto.getPlaceName() + " is not found");
        }
    }

    @Override
    public ResponseEntity<PlaceDTO> getPlaceById(Integer placeId) throws Throwable {
        PlaceDTO placeDTO = new PlaceDTO();
        Place place = placerepository.findById(placeId).orElse(null);
        if (place != null) {
            placeDTO.setPlaceId(place.getPlaceId());
            placeDTO.setPlaceName(place.getPlaceName());
            placeDTO.setImages(place.getImages());
            placeDTO.setAddress(place.getAddress());
            placeDTO.setArea(place.getArea());
            placeDTO.setDistance(place.getDistance());
            placeDTO.setDescription(place.getDescription());
            placeDTO.setTags(place.getTags());
            logger.info("Retrieved place details by ID: {}", placeId);
            return new ResponseEntity<>(placeDTO, HttpStatus.OK);
        } else {
            logger.error("Place not found. PlaceId: {}", placeId);
            throw new PlaceNotFoundException(placeId + " is not found");
        }
    }

    @Override
    public ResponseEntity<List<PlaceDTO>> getPlaceByName(String placeName) throws Throwable {
        List<Place> place = placerepository.findAllByPlaceName(placeName);
        List<PlaceDTO> list = new ArrayList<>();
        if (place != null) {
            for (Place place1 : place) {
                PlaceDTO placeDTO = new PlaceDTO();
                placeDTO.setPlaceId(place1.getPlaceId());
                placeDTO.setPlaceName(place1.getPlaceName());
                placeDTO.setImages(place1.getImages());
                placeDTO.setAddress(place1.getAddress());
                placeDTO.setArea(place1.getArea());
                placeDTO.setDistance(place1.getDistance());
                placeDTO.setDescription(place1.getDescription());
                placeDTO.setTags(place1.getTags());
                list.add(placeDTO);
            }
            logger.info("Retrieved places by name: {}", placeName);
            return new ResponseEntity<>(list, HttpStatus.OK);
        } else {
            logger.error("Place not found. PlaceName: {}", placeName);
            throw new PlaceNotFoundException(placeName + " is not found");
        }
    }

    @Override
    public ResponseEntity<String> deletePlace(String placeName) throws Throwable {
        Place place = placerepository.findByPlaceName(placeName);
        if (place != null) {
            placerepository.delete(place);
            logger.info("Deleted place by name: {}", placeName);
            return new ResponseEntity<>("Place Deleted", HttpStatus.OK);
        } else {
            logger.error("Place not found for deletion. PlaceName: {}", placeName);
            throw new PlaceNotFoundException(placeName + " is not found");
        }
    }

    @Override
    public ResponseEntity<PlaceDTO> getPlaceByTags(String tags) throws Throwable {
        Place place = placerepository.findByTags(tags);
        if (place != null) {
            PlaceDTO placeDTO = new PlaceDTO();
            placeDTO.setPlaceId(place.getPlaceId());
            placeDTO.setPlaceName(place.getPlaceName());
            placeDTO.setImages(place.getImages());
            placeDTO.setAddress(place.getAddress());
            placeDTO.setArea(place.getArea());
            placeDTO.setDistance(place.getDistance());
            placeDTO.setDescription(place.getDescription());
            placeDTO.setTags(place.getTags());
            logger.info("Retrieved place by tags: {}", tags);
            return new ResponseEntity<>(placeDTO, HttpStatus.OK);
        } else {
            logger.error("Place not found. Tags: {}", tags);
            throw new PlaceNotFoundException(tags + " is not found");
        }
    }

    @Override
    public Integer getPlacefortour(Integer placeId) throws Throwable {
        Place placeId1 = placerepository.findById(placeId).orElse(null);
        if (placeId1 != null) {
            Integer placeId2 = placeId1.getPlaceId();
            logger.info("Retrieved place ID for tour: {}", placeId);
            return placeId2;
        } else {
            logger.error("Place not found for tour. PlaceId: {}", placeId);
            throw new PlaceNotFoundException("place is not found with this Id");
        }
    }

    @SuppressWarnings("unused")
    @Override
    public ResponseEntity<List<PlaceDTO>> getListOfPlaceDTOByPlaceId(List<Integer> placeIds) throws Throwable {
        List<Place> place = new ArrayList<>();
        List<PlaceDTO> placeDTOs = new ArrayList<>();
        for (Integer i : placeIds) {
            place.add(placerepository.findById(i).orElse(null));
        }
        if (place != null) {
            for (Place place1 : place) {
                PlaceDTO placeDTO = new PlaceDTO();
                placeDTO.setPlaceId(place1.getPlaceId());
                placeDTO.setPlaceName(place1.getPlaceName());
                placeDTO.setImages(place1.getImages());
                placeDTO.setAddress(place1.getAddress());
                placeDTO.setArea(place1.getArea());
                placeDTO.setDistance(place1.getDistance());
                placeDTO.setDescription(place1.getDescription());
                placeDTO.setTags(place1.getTags());
                placeDTOs.add(placeDTO);
            }
            logger.info("Retrieved places by ID list");
            return new ResponseEntity<>(placeDTOs, HttpStatus.OK);
        } else {
            logger.error("PlaceId's are not found.");
            throw new PlaceNotFoundException("placeId's are not found.");
        }
    }

    @SuppressWarnings("unused")
    @Override
    public ResponseEntity<List<Integer>> getListOfPlaceIdsl(List<Integer> placeIds) throws Throwable {
        List<Integer> placesId = new ArrayList<>();
        for (Integer i : placeIds) {
            Place place = placerepository.findById(i).orElse(null);
            if (place != null) {
                placesId.add(place.getPlaceId());
            }
        }
        if (placesId != null) {
            logger.info("Retrieved places ID list");
            return new ResponseEntity<>(placesId, HttpStatus.OK);
        } else {
            logger.error("PlaceId's are not found.");
            throw new PlaceNotFoundException("placeId's are not found.");
        }
    }

    @Override
    public ResponseEntity<String> deletePlaceById(Integer placeId) throws Throwable {
        Place place = placerepository.findById(placeId).orElse(null);
        if (place != null) {
            placerepository.delete(place);
            logger.info("Deleted place by ID: {}", placeId);
            return new ResponseEntity<>("Place Deleted", HttpStatus.OK);
        } else {
            logger.error("Place not found for deletion. PlaceId: {}", placeId);
            throw new PlaceNotFoundException("Place not found for this Id");
        }
    }
}
